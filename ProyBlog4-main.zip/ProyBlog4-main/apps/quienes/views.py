from django.shortcuts import render

# Create your views here.
def Quienes(request):
    #Creo el diccionario para pasar los datos al templates
    
    #Buscar lo que quiero de la BD
        
    #Pasarlo al template
    
    
    
    return render(request,'quienes/quienes_somos.html')
# Create your views here.
